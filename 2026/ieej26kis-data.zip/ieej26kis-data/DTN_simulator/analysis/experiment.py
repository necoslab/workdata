import pandas as pd
import pynetlogo
import subprocess

netlogo = pynetlogo.NetLogoLink(
    #実験時はFalseにする(実行速度を早くするため)
    gui = False,
)

#モデル読み込み
netlogo.load_model('../models/PRoPHET/trust_prophet.nlogo')
#netlogo.load_model('../models/PRoPHET/prophet.nlogo')


#実験用パラメーターのマッピング
para_map = {
    'comm-range' : '55',
    'num-nodes' : '100',
    'ttl-hops' : '100',
    'buffer-limit' : '20',
    'messages' : '20',
    'p-plus' : '10',
    'blackhole-rate' : '0',
    'evacuee-rate' : '50',
    'history-limit' : '15'
}

#パラメータの設定（NetLogo上でのコマンド）
for name, value in para_map.items():
    observer_cmd = "set " + name + " " + value
    netlogo.command(observer_cmd)

#実験に利用する値
#一回の実験でモデルを実行する回数
experiment_num = 5
ticks_limit = 1500
cmd_analysis = 'python analyze_prophet.py'
cmd_average = 'python analyze_results.py'

#実験のメソッド
def run_experiment(experiment_num):
    for i in range(experiment_num):
        netlogo.command("setup")
        netlogo.command("repeat " + str(ticks_limit) +  " [ go ]")
        subprocess.call(cmd_analysis)
    #平均を求める
    subprocess.call(cmd_average)

#対照実験用のパラメータ
v_name = 'blackhole-rate'
experiment_list = [0, 20, 40, 60, 80]
history_limit = [15]
p_plus_list = []

for para in experiment_list:
    netlogo.command("set " + v_name + " " + str(para))
    run_experiment(experiment_num)

#シミュレーターの停止
netlogo.kill_workspace()